export { default } from './BigText'
